# Formal results

185 SymbiYosys tasks: **155 PASS, 30 FAIL**. Every FAIL is expected: it is either a timing outside the datasheet in a characterization sweep, or the original design's documented lock-up. Inside the datasheet's operating conditions every proof passes.

Solver time summed over tasks: 4.5 h (yosys-abc PDR, k-induction and BMC with yices). The description of every proof is in `docs/FORMAL.md`.

| Group | What | Tasks | PASS | FAIL | Time | Note |
|---|---|---|---|---|---|---|
| O1 | Original ttsky25a SPI slave: timing sweep + 2 covers | 22 | 9 | 13 | 23.3 min | FAIL rows are timings that do not work (see docs/FORMAL.md) |
| O2 | Original frame FSM: protocol, recovery, cover | 3 | 2 | 1 | 24.4 min | recover FAILs by design: the original FSM has no recovery |
| F4 | Original CORDIC engine and quadrant top | 3 | 3 | 0 | 1.3 min |  |
| N1 | SPI slave: timing sweep + 2 covers | 26 | 20 | 6 | 10.9 min | all FAILs are outside the datasheet timings |
| N1C | SPI slave byte contract | 1 | 1 | 0 | 0.0 min |  |
| N1S | SCLK-domain slave (SPI_SCLK = 1): bits, bytes, CDC, contract | 20 | 16 | 4 | 89.5 min | all FAILs are outside the datasheet timings |
| G1 | Default slave at the GF26c pads, through the I/O delays | 20 | 14 | 6 | 73.9 min | the `_x` tasks are documented limits |
| N2 | Frame FSM: legacy x2, recover, command x2, protocol switch, 3 covers | 9 | 9 | 0 | 13.2 min |  |
| F2 | Xcordic engine, GUARD 0 and 4: prove + cover | 4 | 4 | 0 | 23.6 min |  |
| F3 | Xcordic core: every instruction, GUARD 0 and 4 | 70 | 70 | 0 | 12.3 min |  |
| F5 | cordic.bist self-test unit | 4 | 4 | 0 | 1.4 min |  |
| F6 | Exact mul/div/sqrt unit: contract, cover, miter | 3 | 3 | 0 | 0.6 min |  |

Also in this folder: `f7.log` (SAT equivalence of the adder and the angle generator, 12/12 PASS), `equivalence.log` (the current core against the reference core in `equiv/ref/`, 789,864 instructions, 0 mismatches), `exact_*.txt` (exhaustive check of the exact unit).

## Every task

Per-task console output is in `tasks/<task>/logfile.txt`; counterexample and cover traces are `tasks/<task>/*.vcd` (GTKWave).

| Group | Task | Result | Time | Failing assertion |
|---|---|---|---|---|
| O1 | `o1_spi:m0_h2_l5_s5` | FAIL | 8s | o1_slave_props.vh:70.9-70.54 step 17 |
| O1 | `o1_spi:m0_h3_l5_s5` | FAIL | 8s | o1_slave_props.vh:70.9-70.54 step 17 |
| O1 | `o1_spi:m0_h4_l5_s5` | PASS | 33s |  |
| O1 | `o1_spi:m0_h5_l2_s5` | FAIL | 1s | o1_slave_props.vh:76.9-76.52 step 21 |
| O1 | `o1_spi:m0_h5_l3_s5` | FAIL | 1s | o1_slave_props.vh:76.9-76.52 step 22 |
| O1 | `o1_spi:m0_h5_l4_s5` | FAIL | 1s | o1_slave_props.vh:76.9-76.52 step 22 |
| O1 | `o1_spi:m0_h5_l5_s1` | FAIL | 1s | o1_slave_props.vh:75.9-75.31 step 9 |
| O1 | `o1_spi:m0_h5_l5_s2` | FAIL | 1s | o1_slave_props.vh:75.9-75.31 step 10 |
| O1 | `o1_spi:m0_h5_l5_s3` | FAIL | 1s | o1_slave_props.vh:75.9-75.31 step 11 |
| O1 | `o1_spi:m1_h1_l5_s5` | PASS | 33s |  |
| O1 | `o1_spi:m1_h2_l5_s5` | PASS | 36s |  |
| O1 | `o1_spi:m1_h5_l1_s5` | PASS | 34s |  |
| O1 | `o1_spi:m1_h5_l2_s5` | PASS | 36s |  |
| O1 | `o1_spi:m1_h2_l2_s5` | FAIL | 1s | o1_slave_props.vh:76.9-76.52 step 19 |
| O1 | `o1_spi:m1_h2_l1_s5` | FAIL | 1s | o1_slave_props.vh:76.9-76.52 step 18 |
| O1 | `o1_spi:m1_h1_l2_s5` | FAIL | 1s | o1_slave_props.vh:69.9-69.41 step 17 |
| O1 | `o1_spi:m1_h3_l1_s5` | FAIL | 1s | o1_slave_props.vh:76.9-76.52 step 20 |
| O1 | `o1_spi:m1_h1_l3_s5` | FAIL | 1s | o1_slave_props.vh:76.9-76.52 step 19 |
| O1 | `o1_spi:m1_h5_l5_s1` | PASS | 46s |  |
| O1 | `o1_spi:m1_h5_l5_s2` | PASS | 47s |  |
| O1 | `o1_spi:cov_m0` | PASS | 550s |  |
| O1 | `o1_spi:cov_m1` | PASS | 554s |  |
| O2 | `o2_fsm:proto` | PASS | 1392s |  |
| O2 | `o2_fsm:recover` | FAIL | 3s | o2_fsm_props.vh:124.9-124.28 step 92 |
| O2 | `o2_fsm:cover` | PASS | 66s |  |
| F4 | `f4_silicon:engine` | PASS | 31s |  |
| F4 | `f4_silicon:top` | PASS | 48s |  |
| F4 | `f4_silicon:cover` | PASS | 1s |  |
| N1 | `n1_spi:m0_h1_l5_s5` | PASS | 34s |  |
| N1 | `n1_spi:m0_h2_l5_s5` | PASS | 31s |  |
| N1 | `n1_spi:m0_h5_l1_s5` | PASS | 18s |  |
| N1 | `n1_spi:m0_h5_l2_s5` | PASS | 26s |  |
| N1 | `n1_spi:m0_h1_l3_s5` | PASS | 20s |  |
| N1 | `n1_spi:m0_h2_l1_s5` | FAIL | 1s | n1_slave_props.vh:90.9-90.46 step 16 |
| N1 | `n1_spi:m0_h1_l2_s5` | FAIL | 1s | n1_slave_props.vh:90.9-90.46 step 17 |
| N1 | `n1_spi:m0_h2_l2_s5` | PASS | 18s |  |
| N1 | `n1_spi:m0_h5_l5_s1` | FAIL | 1s | n1_slave_props.vh:103.60-103.85 step 11 |
| N1 | `n1_spi:m0_h5_l5_s2` | FAIL | 1s | n1_slave_props.vh:103.60-103.85 step 11 |
| N1 | `n1_spi:m0_h5_l5_s3` | PASS | 28s |  |
| N1 | `n1_spi:m0_h2_l2_s5_fb3` | PASS | 82s |  |
| N1 | `n1_spi:m0_h5_l1_s5_t1` | PASS | 20s |  |
| N1 | `n1_spi:m1_h1_l5_s5` | PASS | 21s |  |
| N1 | `n1_spi:m1_h2_l5_s5` | PASS | 26s |  |
| N1 | `n1_spi:m1_h5_l1_s5` | PASS | 29s |  |
| N1 | `n1_spi:m1_h5_l2_s5` | PASS | 30s |  |
| N1 | `n1_spi:m1_h1_l3_s5` | PASS | 16s |  |
| N1 | `n1_spi:m1_h2_l1_s5` | FAIL | 1s | n1_slave_props.vh:90.9-90.46 step 18 |
| N1 | `n1_spi:m1_h1_l2_s5` | FAIL | 1s | n1_slave_props.vh:90.9-90.46 step 18 |
| N1 | `n1_spi:m1_h2_l2_s5` | PASS | 22s |  |
| N1 | `n1_spi:m1_h5_l5_s1` | PASS | 37s |  |
| N1 | `n1_spi:m1_h2_l2_s5_fb3` | PASS | 111s |  |
| N1 | `n1_spi:m1_h5_l1_s5_t1` | PASS | 34s |  |
| N1 | `n1_spi:cov_m0` | PASS | 24s |  |
| N1 | `n1_spi:cov_m1` | PASS | 22s |  |
| N1C | `n1c_contract:prove` | PASS | 0s |  |
| N1S | `n1s_spi:m0_h3_l3_s12_t1_g24` | PASS | 132s |  |
| N1S | `n1s_spi:m0_h3_l3_s8_t1_g24` | FAIL | 2s | n1s_slave_props.vh:161.32-161.53 step 41 |
| N1S | `n1s_spi:m0_h3_l3_s12_t1_g16` | PASS | 108s |  |
| N1S | `n1s_spi:m0_h3_l3_s12_t1_g12` | FAIL | 46s | n1s_slave_props.vh:161.32-161.53 step 117 |
| N1S | `n1s_spi:m0_h3_l1_s12_t1_g24` | PASS | 88s |  |
| N1S | `n1s_spi:m0_h2_l2_s12_t1_g24` | PASS | 78s |  |
| N1S | `n1s_spi:m0_h1_l1_s12_t1_g24` | PASS | 90s |  |
| N1S | `n1s_spi:m0_h3_l3_s12_t1_g24_fb2` | PASS | 884s |  |
| N1S | `n1s_spi:m0_h1_l2_s12_t1_g24_fb2` | PASS | 637s |  |
| N1S | `n1s_spi:m1_h3_l3_s8_t1_g24` | PASS | 130s |  |
| N1S | `n1s_spi:m1_h3_l3_s4_t1_g24` | FAIL | 2s | n1s_slave_props.vh:159.46-159.67 step 35 |
| N1S | `n1s_spi:m1_h3_l3_s8_t1_g16` | PASS | 142s |  |
| N1S | `n1s_spi:m1_h3_l3_s8_t1_g12` | FAIL | 47s | n1s_slave_props.vh:159.46-159.67 step 111 |
| N1S | `n1s_spi:m1_h3_l1_s8_t1_g24` | PASS | 132s |  |
| N1S | `n1s_spi:m1_h2_l2_s8_t1_g24` | PASS | 79s |  |
| N1S | `n1s_spi:m1_h1_l1_s8_t1_g24` | PASS | 86s |  |
| N1S | `n1s_spi:m1_h3_l3_s8_t1_g24_fb2` | PASS | 841s |  |
| N1S | `n1s_spi:m1_h2_l1_s8_t1_g24_fb2` | PASS | 997s |  |
| N1S | `n1s_spi:cov_m0` | PASS | 459s |  |
| N1S | `n1s_spi:cov_m1` | PASS | 390s |  |
| G1 | `g1_spi:k1_m0_h4_l4_s7_t2_g12_i01_o01_d1` | PASS | 159s |  |
| G1 | `g1_spi:k1_m1_h4_l4_s7_t2_g12_i01_o01_d1` | PASS | 175s |  |
| G1 | `g1_spi:k1_m0_h4_l4_s7_t2_g12_i01_o01_d1_fb2` | PASS | 761s |  |
| G1 | `g1_spi:k1_m1_h4_l4_s7_t2_g12_i01_o01_d1_fb2` | PASS | 467s |  |
| G1 | `g1_spi:k1_m0_h4_l5_s7_t2_g12_i01_o01_d0` | PASS | 291s |  |
| G1 | `g1_spi:k1_m1_h5_l4_s7_t2_g12_i01_o01_d0` | PASS | 205s |  |
| G1 | `g1_spi:k1_m0_h3_l5_s7_t2_g12_i01_o01_d1` | PASS | 154s |  |
| G1 | `g1_spi:k1_m1_h5_l3_s7_t2_g12_i01_o01_d1` | PASS | 233s |  |
| G1 | `g1_spi:k1_m1_h4_l4_s3_t2_g12_i01_o01_d1` | PASS | 164s |  |
| G1 | `g1_spi:k1_m0_h4_l4_s6_t2_g12_i01_o01_d1` | PASS | 186s |  |
| G1 | `g1_spi:k2_m0_h8_l8_s12_t4_g24_i01_o02_d0` | PASS | 684s |  |
| G1 | `g1_spi:k2_m1_h8_l8_s12_t4_g24_i01_o02_d0` | PASS | 899s |  |
| G1 | `g1_spi:k1_m0_h4_l4_s5_t2_g12_i01_o01_d1_x` | FAIL | 2s | g1_slave_props.vh:146.43-146.90 step 21 |
| G1 | `g1_spi:k1_m0_h4_l4_s7_t2_g12_i01_o01_d0_x` | FAIL | 3s | g1_slave_props.vh:146.43-146.90 step 31 |
| G1 | `g1_spi:k1_m0_h2_l6_s7_t2_g12_i01_o01_d1_x` | FAIL | 3s | g1_slave_props.vh:121.18-121.45 step 31 |
| G1 | `g1_spi:k1_m1_h6_l2_s7_t2_g12_i01_o01_d1_x` | FAIL | 3s | g1_slave_props.vh:121.18-121.45 step 37 |
| G1 | `g1_spi:k1_m0_h4_l4_s7_t2_g12_i02_o02_d2_x` | FAIL | 3s | g1_slave_props.vh:146.43-146.90 step 34 |
| G1 | `g1_spi:k2_m0_h8_l8_s12_t4_g24_i01_o03_d0_x` | FAIL | 4s | g1_slave_props.vh:146.43-146.90 step 44 |
| G1 | `g1_spi:cov_m0` | PASS | 18s |  |
| G1 | `g1_spi:cov_m1` | PASS | 20s |  |
| N2 | `n2_top:legacy_g0` | PASS | 60s |  |
| N2 | `n2_top:legacy_g4` | PASS | 50s |  |
| N2 | `n2_top:recover_g4` | PASS | 72s |  |
| N2 | `n2_top:cmd_g0` | PASS | 191s |  |
| N2 | `n2_top:cmd_g4` | PASS | 192s |  |
| N2 | `n2_top:cov_legacy` | PASS | 71s |  |
| N2 | `n2_top:cov_cmd` | PASS | 114s |  |
| N2 | `n2_top:switch_g4` | PASS | 1s |  |
| N2 | `n2_top:cov_switch` | PASS | 42s |  |
| F2 | `f2_engine:prove_g0` | PASS | 309s |  |
| F2 | `f2_engine:cover_g0` | PASS | 2s |  |
| F2 | `f2_engine:prove_g4` | PASS | 1101s |  |
| F2 | `f2_engine:cover_g4` | PASS | 4s |  |
| F3 | `f3_core:a_funcs1_g0` | PASS | 8s |  |
| F3 | `f3_core:a_funcs0_g0` | PASS | 6s |  |
| F3 | `f3_core:b_op0_g0` | PASS | 6s |  |
| F3 | `f3_core:b_op1_g0` | PASS | 6s |  |
| F3 | `f3_core:b_op2_g0` | PASS | 5s |  |
| F3 | `f3_core:b_op3_g0` | PASS | 4s |  |
| F3 | `f3_core:b_op4_g0` | PASS | 4s |  |
| F3 | `f3_core:b_op5_g0` | PASS | 5s |  |
| F3 | `f3_core:b_op6_g0` | PASS | 5s |  |
| F3 | `f3_core:b_op7_g0` | PASS | 4s |  |
| F3 | `f3_core:b_op8_g0` | PASS | 6s |  |
| F3 | `f3_core:b_op9_g0` | PASS | 6s |  |
| F3 | `f3_core:b_op10_g0` | PASS | 29s |  |
| F3 | `f3_core:b_op11_g0` | PASS | 11s |  |
| F3 | `f3_core:b_op12_g0` | PASS | 21s |  |
| F3 | `f3_core:b_op13_g0` | PASS | 7s |  |
| F3 | `f3_core:b_op14_g0` | PASS | 12s |  |
| F3 | `f3_core:b_op15_g0` | PASS | 6s |  |
| F3 | `f3_core:b_op16_g0` | PASS | 6s |  |
| F3 | `f3_core:b_op17_g0` | PASS | 6s |  |
| F3 | `f3_core:b_op18_g0` | PASS | 43s |  |
| F3 | `f3_core:b_op19_g0` | PASS | 32s |  |
| F3 | `f3_core:b0_op0_g0` | PASS | 6s |  |
| F3 | `f3_core:b0_op1_g0` | PASS | 6s |  |
| F3 | `f3_core:b0_op2_g0` | PASS | 5s |  |
| F3 | `f3_core:b0_op3_g0` | PASS | 4s |  |
| F3 | `f3_core:b0_op4_g0` | PASS | 4s |  |
| F3 | `f3_core:b0_op5_g0` | PASS | 5s |  |
| F3 | `f3_core:b0_op6_g0` | PASS | 5s |  |
| F3 | `f3_core:b0_op7_g0` | PASS | 4s |  |
| F3 | `f3_core:cov_op10_g0` | PASS | 4s |  |
| F3 | `f3_core:cov_op12_g0` | PASS | 3s |  |
| F3 | `f3_core:cov_op17_g0` | PASS | 2s |  |
| F3 | `f3_core:cov_op18_g0` | PASS | 5s |  |
| F3 | `f3_core:cov_op19_g0` | PASS | 5s |  |
| F3 | `f3_core:a_funcs1_g4` | PASS | 8s |  |
| F3 | `f3_core:a_funcs0_g4` | PASS | 7s |  |
| F3 | `f3_core:b_op0_g4` | PASS | 8s |  |
| F3 | `f3_core:b_op1_g4` | PASS | 8s |  |
| F3 | `f3_core:b_op2_g4` | PASS | 7s |  |
| F3 | `f3_core:b_op3_g4` | PASS | 6s |  |
| F3 | `f3_core:b_op4_g4` | PASS | 6s |  |
| F3 | `f3_core:b_op5_g4` | PASS | 7s |  |
| F3 | `f3_core:b_op6_g4` | PASS | 7s |  |
| F3 | `f3_core:b_op7_g4` | PASS | 5s |  |
| F3 | `f3_core:b_op8_g4` | PASS | 7s |  |
| F3 | `f3_core:b_op9_g4` | PASS | 7s |  |
| F3 | `f3_core:b_op10_g4` | PASS | 50s |  |
| F3 | `f3_core:b_op11_g4` | PASS | 16s |  |
| F3 | `f3_core:b_op12_g4` | PASS | 28s |  |
| F3 | `f3_core:b_op13_g4` | PASS | 9s |  |
| F3 | `f3_core:b_op14_g4` | PASS | 15s |  |
| F3 | `f3_core:b_op15_g4` | PASS | 9s |  |
| F3 | `f3_core:b_op16_g4` | PASS | 9s |  |
| F3 | `f3_core:b_op17_g4` | PASS | 9s |  |
| F3 | `f3_core:b_op18_g4` | PASS | 87s |  |
| F3 | `f3_core:b_op19_g4` | PASS | 57s |  |
| F3 | `f3_core:b0_op0_g4` | PASS | 7s |  |
| F3 | `f3_core:b0_op1_g4` | PASS | 8s |  |
| F3 | `f3_core:b0_op2_g4` | PASS | 7s |  |
| F3 | `f3_core:b0_op3_g4` | PASS | 6s |  |
| F3 | `f3_core:b0_op4_g4` | PASS | 6s |  |
| F3 | `f3_core:b0_op5_g4` | PASS | 7s |  |
| F3 | `f3_core:b0_op6_g4` | PASS | 6s |  |
| F3 | `f3_core:b0_op7_g4` | PASS | 5s |  |
| F3 | `f3_core:cov_op10_g4` | PASS | 5s |  |
| F3 | `f3_core:cov_op12_g4` | PASS | 4s |  |
| F3 | `f3_core:cov_op17_g4` | PASS | 2s |  |
| F3 | `f3_core:cov_op18_g4` | PASS | 5s |  |
| F3 | `f3_core:cov_op19_g4` | PASS | 5s |  |
| F5 | `f5_bist:prove_f1` | PASS | 8s |  |
| F5 | `f5_bist:prove_f0` | PASS | 8s |  |
| F5 | `f5_bist:cover` | PASS | 0s |  |
| F5 | `f5_bist:bmc_f1` | PASS | 69s |  |
| F6 | `f6_exact:contract` | PASS | 1s |  |
| F6 | `f6_exact:cover` | PASS | 2s |  |
| F6 | `f6_exact:miter` | PASS | 32s |  |
